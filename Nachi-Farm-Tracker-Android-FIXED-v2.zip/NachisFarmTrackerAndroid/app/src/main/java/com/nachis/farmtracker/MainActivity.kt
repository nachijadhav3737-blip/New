package com.nachis.farmtracker

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = FarmDatabase.get(this).dao()
        setContent { FarmApp(dao) }
    }
}

private enum class Page { DASHBOARD, PLOTS, LABOUR, DIESEL, OTHER, ACTIVITIES, REPORTS, SETTINGS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FarmApp(dao: FarmDao) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("farm_prefs", 0) }
    var pinReady by remember { mutableStateOf(prefs.contains("pin")) }
    var unlocked by remember { mutableStateOf(!pinReady) }
    var pinInput by remember { mutableStateOf("") }
    var showPinSetup by remember { mutableStateOf(!prefs.contains("pin")) }
    var newPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf("") }
    var language by remember { mutableStateOf(prefs.getString("language", "en") ?: "en") }
    var page by remember { mutableStateOf(Page.DASHBOARD) }
    var showAddPlot by remember { mutableStateOf(false) }
    var showAddEntry by remember { mutableStateOf(false) }
    var entryType by remember { mutableStateOf("Other purchase") }
    val plots by dao.plots().collectAsState(initial = emptyList())
    val entries by dao.entries().collectAsState(initial = emptyList())
    val total by dao.totalExpense().collectAsState(initial = 0.0)
    val scope = rememberCoroutineScope()
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) scope.launch {
            val csv = buildString {
                appendLine("Date,Plot,Type,Description,Quantity,Unit,Workers,Amount,Paid")
                val plotMap = plots.associateBy { it.id }
                entries.forEach { e ->
                    val name = e.plotId?.let { plotMap[it]?.name } ?: ""
                    appendLine(listOf(e.date, name, e.type, e.description, e.quantity, e.unit, e.workerCount, e.amount, e.paid)
                        .joinToString(",") { csvEscape(it.toString()) })
                }
            }
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(csv) }
        }
    }
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) scope.launch {
            val document = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas
            val paint = Paint().apply { textSize = 18f; isFakeBoldText = true }
            canvas.drawText("Nachi's Farm Tracker - Expense Report", 40f, 48f, paint)
            paint.textSize = 11f; paint.isFakeBoldText = false
            canvas.drawText("Total expenses: Rs. ${"%.2f".format(total)}", 40f, 75f, paint)
            var y = 105f
            canvas.drawText("Date | Plot | Type | Description | Amount (Rs.)", 40f, y, paint)
            y += 22f
            val plotMap = plots.associateBy { it.id }
            entries.take(28).forEach { e ->
                val line = "${e.date} | ${plotMap[e.plotId]?.name ?: "General"} | ${e.type} | ${e.description.take(28)} | ${"%.2f".format(e.amount)}"
                canvas.drawText(line.take(95), 40f, y, paint)
                y += 18f
            }
            document.finishPage(page)
            context.contentResolver.openOutputStream(uri)?.use { document.writeTo(it) }
            document.close()
        }
    }
    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            val root = JSONObject()
            val pa = JSONArray()
            plots.forEach { p -> pa.put(JSONObject().put("id", p.id).put("name", p.name).put("crop", p.crop).put("area", p.area).put("createdAt", p.createdAt)) }
            val ea = JSONArray()
            entries.forEach { e ->
                ea.put(JSONObject().put("id", e.id).put("plotId", e.plotId ?: JSONObject.NULL)
                    .put("date", e.date).put("type", e.type).put("description", e.description)
                    .put("quantity", e.quantity).put("unit", e.unit).put("amount", e.amount)
                    .put("workerCount", e.workerCount).put("paid", e.paid).put("createdAt", e.createdAt))
            }
            root.put("app", "Nachi's Farm Tracker").put("version", 1).put("plots", pa).put("entries", ea)
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(root.toString(2)) }
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: return@runCatching
                val root = JSONObject(raw)
                dao.clearEntries()
                dao.clearPlots()
                val pa = root.getJSONArray("plots")
                val plotIdMap = mutableMapOf<Long, Long>()
                for (i in 0 until pa.length()) {
                    val p = pa.getJSONObject(i)
                    val oldId = p.optLong("id")
                    val newId = dao.addPlot(Plot(name = p.getString("name"), crop = p.optString("crop", "Grapes"), area = p.optString("area", "")))
                    plotIdMap[oldId] = newId
                }
                val ea = root.getJSONArray("entries")
                for (i in 0 until ea.length()) {
                    val e = ea.getJSONObject(i)
                    val oldPlotId = if (e.isNull("plotId")) null else plotIdMap[e.optLong("plotId")]
                    dao.addEntry(FarmEntry(plotId = oldPlotId, date = e.optString("date"), type = e.optString("type"),
                        description = e.optString("description"), quantity = e.optDouble("quantity"),
                        unit = e.optString("unit"), amount = e.optDouble("amount"), workerCount = e.optInt("workerCount"),
                        paid = e.optBoolean("paid", true)))
                }
            }
        }
    }

    MaterialTheme {
        if (pinReady && !unlocked) {
            PinScreen(pinInput, { pinInput = it }, {
                if (pinInput == prefs.getString("pin", "")) { unlocked = true; pinInput = "" }
                else pinInput = ""
            }, false, {}, language)
            return@MaterialTheme
        }
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (language == "mr") "Nachikेतचे Farm Tracker" else "Nachi's Farm Tracker") },
                    actions = {
                        TextButton(onClick = { page = Page.SETTINGS }) { Icon(Icons.Default.Settings, contentDescription = "Settings") }
                        TextButton(onClick = { language = if (language == "en") "mr" else "en"; prefs.edit().putString("language", language).apply() }) {
                            Text(if (language == "en") "मराठी" else "English")
                        }
                    }
                )
            },
            floatingActionButton = {
                if (page == Page.PLOTS || page in listOf(Page.LABOUR, Page.DIESEL, Page.OTHER, Page.ACTIVITIES)) {
                    FloatingActionButton(onClick = {
                        if (page == Page.PLOTS) showAddPlot = true else {
                            entryType = when (page) {
                                Page.LABOUR -> "Labour"
                                Page.DIESEL -> "Diesel"
                                Page.ACTIVITIES -> "Spray/Fertilizer"
                                else -> "Other purchase"
                            }
                            showAddEntry = true
                        }
                    }) { Icon(Icons.Default.Add, contentDescription = "Add") }
                }
            },
            bottomBar = {
                NavigationBar {
                    val items = listOf(
                        Page.DASHBOARD to (if (language == "mr") "मुख्य" else "Home"),
                        Page.PLOTS to (if (language == "mr") "प्लॉट" else "Plots"),
                        Page.LABOUR to (if (language == "mr") "मजूर" else "Labour"),
                        Page.OTHER to (if (language == "mr") "खर्च" else "Expenses"),
                        Page.REPORTS to (if (language == "mr") "रिपोर्ट" else "Reports")
                    )
                    items.forEach { (p, label) ->
                        NavigationBarItem(selected = page == p, onClick = { page = p }, icon = {
                            Icon(when (p) {
                                Page.DASHBOARD -> Icons.Default.Home
                                Page.PLOTS -> Icons.Default.Spa
                                Page.LABOUR -> Icons.Default.Groups
                                Page.OTHER -> Icons.Default.ReceiptLong
                                else -> Icons.Default.Assessment
                            }, contentDescription = label)
                        }, label = { Text(label) })
                    }
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
                when (page) {
                    Page.DASHBOARD -> Dashboard(plots, entries, total, language) { page = it }
                    Page.PLOTS -> PlotsPage(plots, entries, language)
                    Page.LABOUR -> EntriesPage(entries.filter { it.type == "Labour" }, plots, language)
                    Page.DIESEL -> EntriesPage(entries.filter { it.type == "Diesel" }, plots, language)
                    Page.OTHER -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { page = Page.DIESEL }) { Text(if (language == "mr") "डिझेल" else "Diesel") }
                            Button(onClick = { page = Page.ACTIVITIES }) { Text(if (language == "mr") "फवारणी/खत" else "Spray/Fertilizer") }
                        }
                        Spacer(Modifier.height(8.dp))
                        EntriesPage(entries.filter { it.type == "Other purchase" }, plots, language)
                    }
                    Page.ACTIVITIES -> EntriesPage(entries.filter { it.type == "Spray/Fertilizer" }, plots, language)
                    Page.REPORTS -> ReportsPage(entries, plots, total, language, { exportLauncher.launch("Nachi-Farm-Report.csv") }, { pdfLauncher.launch("Nachi-Farm-Report.pdf") }, { backupLauncher.launch("Nachi-Farm-Backup.json") }, { restoreLauncher.launch(arrayOf("application/json", "text/*")) })
                    Page.SETTINGS -> SettingsPage(pinReady, {
                        pinReady = false
                        prefs.edit().remove("pin").apply()
                        newPin = ""; confirmPin = ""; pinError = ""; showPinSetup = true
                    }, { newPin = ""; confirmPin = ""; pinError = ""; showPinSetup = true }, language)
                }
            }
        }
    }

    if (showAddPlot) AddPlotDialog(language, { showAddPlot = false }) { name, crop, area ->
        scope.launch { dao.addPlot(Plot(name = name, crop = crop, area = area)) }
        showAddPlot = false
    }
    if (showAddEntry) AddEntryDialog(language, plots, entryType, { showAddEntry = false }) { e ->
        scope.launch { dao.addEntry(e) }
        showAddEntry = false
    }
    if (showPinSetup) AlertDialog(
        onDismissRequest = { if (pinReady) showPinSetup = false },
        title = { Text(if (language == "mr") "PIN लॉक सेट करा" else "Set app PIN") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (language == "mr") "4 ते 8 अंकांचा PIN निवडा." else "Choose a 4–8 digit PIN. It is stored locally on this device.")
            OutlinedTextField(newPin, { newPin = it.filter(Char::isDigit).take(8) }, label = { Text("New PIN") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
            OutlinedTextField(confirmPin, { confirmPin = it.filter(Char::isDigit).take(8) }, label = { Text("Confirm PIN") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
            if (pinError.isNotBlank()) Text(pinError, color = MaterialTheme.colorScheme.error)
        } },
        confirmButton = { TextButton(onClick = {
            if (newPin.length !in 4..8) pinError = if (language == "mr") "PIN 4 ते 8 अंकांचा असावा." else "PIN must be 4–8 digits."
            else if (newPin != confirmPin) pinError = if (language == "mr") "PIN जुळत नाही." else "PINs do not match."
            else { prefs.edit().putString("pin", newPin).apply(); pinReady = true; unlocked = true; showPinSetup = false; newPin = ""; confirmPin = ""; pinError = "" }
        }) { Text(if (language == "mr") "जतन करा" else "Save PIN") } },
        dismissButton = { if (pinReady) TextButton(onClick = { showPinSetup = false }) { Text(if (language == "mr") "रद्द" else "Cancel") } }
    )
}

private fun csvEscape(value: String): String = "\"" + value.replace("\"", "\"\"") + "\""

@Composable
private fun Dashboard(plots: List<Plot>, entries: List<FarmEntry>, total: Double, language: String, navigate: (Page) -> Unit) {
    Text(if (language == "mr") "शेताचा आढावा" else "Farm overview", style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SummaryCard(if (language == "mr") "एकूण प्लॉट" else "Total plots", plots.size.toString(), Modifier.weight(1f))
        SummaryCard(if (language == "mr") "एकूण खर्च" else "Total expenses", "₹${"%.2f".format(total)}", Modifier.weight(1f))
    }
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SummaryCard(if (language == "mr") "मजूर नोंदी" else "Labour records", entries.count { it.type == "Labour" }.toString(), Modifier.weight(1f))
        SummaryCard(if (language == "mr") "डिझेल नोंदी" else "Diesel records", entries.count { it.type == "Diesel" }.toString(), Modifier.weight(1f))
    }
    Spacer(Modifier.height(16.dp))
    Text(if (language == "mr") "जलद नोंदी" else "Quick entry", style = MaterialTheme.typography.titleMedium)
    listOf(
        "Labour" to (if (language == "mr") "मजूर उपस्थिती" else "Daily labour attendance"),
        "Diesel" to (if (language == "mr") "डिझेल खरेदी" else "Diesel purchase"),
        "Other purchase" to (if (language == "mr") "इतर खरेदी" else "Other purchase"),
        "Spray/Fertilizer" to (if (language == "mr") "फवारणी / खत" else "Spray / Fertilizer")
    ).forEach { (type, label) ->
        OutlinedButton(onClick = { navigate(when(type) { "Labour" -> Page.LABOUR; "Diesel" -> Page.DIESEL; "Spray/Fertilizer" -> Page.ACTIVITIES; else -> Page.OTHER }) }, modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) { Text(label) }
    }
    Spacer(Modifier.height(10.dp))
    Text(if (language == "mr") "अलीकडील नोंदी" else "Recent entries", style = MaterialTheme.typography.titleMedium)
    entries.take(5).forEach { e ->
        ListItem(headlineContent = { Text(e.description.ifBlank { e.type }) }, supportingContent = { Text("${e.date} • ${e.type}") }, trailingContent = { Text("₹${"%.0f".format(e.amount)}") })
    }
}

@Composable
private fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(16.dp)) { Text(title, style = MaterialTheme.typography.bodyMedium); Spacer(Modifier.height(8.dp)); Text(value, style = MaterialTheme.typography.titleLarge) } }
}

@Composable
private fun PlotsPage(plots: List<Plot>, entries: List<FarmEntry>, language: String) {
    Text(if (language == "mr") "तुमचे प्लॉट" else "Your plots", style = MaterialTheme.typography.headlineSmall)
    if (plots.isEmpty()) Text(if (language == "mr") "＋ वापरून पहिला प्लॉट जोडा." else "Use + to add your first plot.")
    LazyColumn {
        items(plots, key = { it.id }) { plot ->
            val expenses = entries.filter { it.plotId == plot.id }.sumOf { it.amount }
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text(plot.name, style = MaterialTheme.typography.titleMedium)
                    Text("${plot.crop} ${if (plot.area.isNotBlank()) "• ${plot.area}" else ""}")
                    Text("Expenses: ₹${"%.2f".format(expenses)}")
                }
            }
        }
    }
}

@Composable
private fun EntriesPage(entries: List<FarmEntry>, plots: List<Plot>, language: String) {
    Text(if (language == "mr") "नोंदी" else "Records", style = MaterialTheme.typography.headlineSmall)
    if (entries.isEmpty()) Text(if (language == "mr") "अजून नोंदी नाहीत. + दाबून नोंद जोडा." else "No records yet. Tap + to add one.")
    LazyColumn {
        items(entries, key = { it.id }) { e ->
            val plotName = plots.firstOrNull { it.id == e.plotId }?.name ?: "General"
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                ListItem(
                    headlineContent = { Text(e.description.ifBlank { e.type }) },
                    supportingContent = { Text("${e.date} • $plotName • ${e.type}" + if (e.workerCount > 0) " • ${e.workerCount} workers" else "") },
                    trailingContent = { Text("₹${"%.2f".format(e.amount)}") }
                )
            }
        }
    }
}

@Composable
private fun ReportsPage(entries: List<FarmEntry>, plots: List<Plot>, total: Double, language: String, export: () -> Unit, exportPdf: () -> Unit, backup: () -> Unit, restore: () -> Unit) {
    Text(if (language == "mr") "रिपोर्ट व बॅकअप" else "Reports & backup", style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(12.dp))
    SummaryCard(if (language == "mr") "एकूण खर्च" else "Total expenses", "₹${"%.2f".format(total)}", Modifier.fillMaxWidth())
    Spacer(Modifier.height(12.dp))
    Button(onClick = export, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.TableChart, null); Spacer(Modifier.width(8.dp)); Text(if (language == "mr") "Excel साठी CSV निर्यात" else "Export CSV for Excel") }
    OutlinedButton(onClick = exportPdf, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(8.dp)); Text(if (language == "mr") "PDF रिपोर्ट" else "PDF report") }
    OutlinedButton(onClick = backup, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Backup, null); Spacer(Modifier.width(8.dp)); Text(if (language == "mr") "बॅकअप तयार करा" else "Create backup") }
    OutlinedButton(onClick = restore, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Restore, null); Spacer(Modifier.width(8.dp)); Text(if (language == "mr") "बॅकअप पुनर्संचयित करा" else "Restore backup") }
    Spacer(Modifier.height(12.dp))
    Text(if (language == "mr") "प्रकारानुसार खर्च" else "Expense by type", style = MaterialTheme.typography.titleMedium)
    entries.groupBy { it.type }.forEach { (type, group) ->
        ListItem(headlineContent = { Text(type) }, trailingContent = { Text("₹${"%.2f".format(group.sumOf { it.amount })}") })
    }
    Text(if (language == "mr") "CSV Excel मध्ये उघडता येते. PDF रिपोर्टमध्ये पहिल्या 28 नोंदी येतात." else "CSV opens in Excel. The PDF summary currently includes up to 28 records on one page.", style = MaterialTheme.typography.bodySmall)
}

@Composable
private fun SettingsPage(pinReady: Boolean, clearPin: () -> Unit, setPin: () -> Unit, language: String) {
    Text(if (language == "mr") "सेटिंग्ज" else "Settings", style = MaterialTheme.typography.headlineSmall)
    Text(if (pinReady) (if (language == "mr") "PIN लॉक सुरू आहे" else "PIN lock is enabled") else (if (language == "mr") "PIN सेट केलेला नाही" else "No PIN is set"))
    OutlinedButton(onClick = setPin) { Text(if (language == "mr") "PIN सेट / बदला" else "Set / change PIN") }
    if (pinReady) OutlinedButton(onClick = clearPin) { Text(if (language == "mr") "PIN काढा" else "Remove PIN") }
}

@Composable
private fun AddPlotDialog(language: String, dismiss: () -> Unit, save: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var crop by remember { mutableStateOf("Grapes") }
    var area by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = dismiss, title = { Text(if (language == "mr") "नवीन प्लॉट" else "New plot") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text(if (language == "mr") "प्लॉटचे नाव" else "Plot name") }, singleLine = true)
            OutlinedTextField(crop, { crop = it }, label = { Text(if (language == "mr") "पीक" else "Crop") }, singleLine = true)
            OutlinedTextField(area, { area = it }, label = { Text(if (language == "mr") "क्षेत्र (ऐच्छिक)" else "Area (optional)") }, singleLine = true)
        } }, confirmButton = { TextButton(onClick = { if (name.isNotBlank()) save(name.trim(), crop.trim(), area.trim()) }) { Text(if (language == "mr") "जतन करा" else "Save") } },
        dismissButton = { TextButton(onClick = dismiss) { Text(if (language == "mr") "रद्द" else "Cancel") } })
}

@Composable
private fun AddEntryDialog(language: String, plots: List<Plot>, type: String, dismiss: () -> Unit, save: (FarmEntry) -> Unit) {
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    var date by remember { mutableStateOf(today) }
    var description by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("") }
    var workers by remember { mutableStateOf("") }
    var selectedPlot by remember { mutableStateOf(plots.firstOrNull()?.id) }
    var paid by remember { mutableStateOf(true) }
    var expanded by remember { mutableStateOf(false) }
    val plotName = plots.firstOrNull { it.id == selectedPlot }?.name ?: (if (language == "mr") "सामान्य" else "General")
    AlertDialog(onDismissRequest = dismiss, title = { Text(if (language == "mr") "नोंद जोडा: $type" else "Add record: $type") },
        text = { Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(date, { date = it }, label = { Text(if (language == "mr") "तारीख (YYYY-MM-DD)" else "Date (YYYY-MM-DD)") }, singleLine = true)
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(plotName, {}, readOnly = true, label = { Text(if (language == "mr") "प्लॉट" else "Plot") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    DropdownMenuItem(text = { Text(if (language == "mr") "सामान्य" else "General") }, onClick = { selectedPlot = null; expanded = false })
                    plots.forEach { p -> DropdownMenuItem(text = { Text(p.name) }, onClick = { selectedPlot = p.id; expanded = false }) }
                }
            }
            OutlinedTextField(description, { description = it }, label = { Text(if (language == "mr") "तपशील" else "Description") }, singleLine = true)
            if (type == "Labour") {
                OutlinedTextField(workers, { workers = it }, label = { Text(if (language == "mr") "मजुरांची संख्या" else "Worker count") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(amount, { amount = it }, label = { Text(if (language == "mr") "एकूण मजुरी ₹" else "Total labour cost ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            } else {
                OutlinedTextField(quantity, { quantity = it }, label = { Text(if (language == "mr") "प्रमाण" else "Quantity") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(unit, { unit = it }, label = { Text(if (language == "mr") "एकक" else "Unit") }, singleLine = true)
                OutlinedTextField(amount, { amount = it }, label = { Text(if (language == "mr") "किंमत / खर्च ₹" else "Price / amount ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            }
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = paid, onCheckedChange = { paid = it }); Text(if (language == "mr") "पैसे दिले" else "Paid") }
        } }, confirmButton = { TextButton(onClick = {
            val validAmount = amount.toDoubleOrNull() ?: 0.0
            save(FarmEntry(plotId = selectedPlot, date = date.ifBlank { today }, type = type, description = description,
                quantity = quantity.toDoubleOrNull() ?: 0.0, unit = unit, amount = validAmount,
                workerCount = workers.toIntOrNull() ?: 0, paid = paid))
        }) { Text(if (language == "mr") "जतन करा" else "Save") } },
        dismissButton = { TextButton(onClick = dismiss) { Text(if (language == "mr") "रद्द" else "Cancel") } })
}

@Composable
private fun PinScreen(pin: String, onPinChange: (String) -> Unit, onUnlock: () -> Unit, setup: Boolean, onSet: (String) -> Unit, language: String) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.Lock, null, Modifier.size(56.dp))
        Text("Nachi's Farm Tracker", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(pin, onPinChange, label = { Text(if (language == "mr") "PIN टाका" else "Enter PIN") },
            visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onUnlock) { Text(if (language == "mr") "अनलॉक" else "Unlock") }
    }
}
