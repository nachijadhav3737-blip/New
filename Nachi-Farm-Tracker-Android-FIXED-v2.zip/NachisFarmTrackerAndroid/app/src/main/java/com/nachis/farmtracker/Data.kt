package com.nachis.farmtracker

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "plots")
data class Plot(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val crop: String = "Grapes",
    val area: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "entries",
    indices = [Index("plotId"), Index("date"), Index("type")]
)
data class FarmEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val plotId: Long? = null,
    val date: String,
    val type: String,
    val description: String,
    val quantity: Double = 0.0,
    val unit: String = "",
    val amount: Double = 0.0,
    val workerCount: Int = 0,
    val paid: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface FarmDao {
    @Query("SELECT * FROM plots ORDER BY name")
    fun plots(): Flow<List<Plot>>

    @Insert
    suspend fun addPlot(plot: Plot): Long

    @Update
    suspend fun updatePlot(plot: Plot)

    @Delete
    suspend fun deletePlot(plot: Plot)

    @Query("SELECT * FROM entries ORDER BY date DESC, id DESC")
    fun entries(): Flow<List<FarmEntry>>

    @Query("SELECT * FROM entries WHERE plotId = :plotId ORDER BY date DESC, id DESC")
    fun entriesForPlot(plotId: Long): Flow<List<FarmEntry>>

    @Insert
    suspend fun addEntry(entry: FarmEntry): Long

    @Update
    suspend fun updateEntry(entry: FarmEntry)

    @Delete
    suspend fun deleteEntry(entry: FarmEntry)

    @Query("SELECT COALESCE(SUM(amount), 0) FROM entries")
    fun totalExpense(): Flow<Double>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM entries WHERE date = :date")
    fun expenseForDate(date: String): Flow<Double>

    @Query("DELETE FROM entries")
    suspend fun clearEntries()

    @Query("DELETE FROM plots")
    suspend fun clearPlots()

    @Query("SELECT * FROM plots")
    suspend fun allPlotsOnce(): List<Plot>

    @Query("SELECT * FROM entries")
    suspend fun allEntriesOnce(): List<FarmEntry>
}

@Database(entities = [Plot::class, FarmEntry::class], version = 1, exportSchema = false)
abstract class FarmDatabase : RoomDatabase() {
    abstract fun dao(): FarmDao

    companion object {
        @Volatile private var INSTANCE: FarmDatabase? = null
        fun get(context: Context): FarmDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    FarmDatabase::class.java,
                    "nachis_farm_tracker.db"
                ).build().also { INSTANCE = it }
            }
    }
}
