# Nachi's Farm Tracker — Android

This is a native Android/Jetpack Compose project for **Nachi's Farm Tracker**.

## Features
- Multiple plots with custom names
- Dashboard totals
- Labour, diesel, other purchase and spray/fertilizer records
- Marathi / English switch
- Local PIN lock
- CSV export (Excel-compatible)
- PDF report
- JSON backup / restore
- Offline Room database
- Grape-themed launcher icon
- GitHub Actions APK build

## Build the APK using GitHub Actions (phone-friendly)

1. Create a GitHub repository.
2. Upload the **contents of this folder** to the repository (the folder containing `settings.gradle.kts`).
3. Open the repository's **Actions** tab.
4. Select **Build Nachi's Farm Tracker APK**.
5. Tap **Run workflow**.
6. Wait for the workflow to finish.
7. Open the completed workflow run.
8. Download the artifact named **Nachi-Farm-Tracker-debug-apk**.
9. Extract it and install the APK on your Android phone.

The workflow installs Android SDK platform/build tools automatically and runs Gradle from the correct project directory.

## Android Studio
Alternatively, open the folder containing `settings.gradle.kts` in Android Studio and build:
**Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Important
This source project is intended for testing and personal farm records. The PIN is an app lock; it is not database encryption.
